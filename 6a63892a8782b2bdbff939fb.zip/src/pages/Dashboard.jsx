const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, TrendingUp } from "lucide-react";
import AppChrome from "@/components/dysentry/AppChrome";
import Button from "@/components/dysentry/Button";

import { Image } from "@/components/ui/image";
import { AreaChart, Area, XAxis, ResponsiveContainer, Tooltip } from "recharts";

const chartData = [
  { ep: "E01", views: 12000 },
  { ep: "E02", views: 18500 },
  { ep: "E03", views: 16400 },
  { ep: "E04", views: 24000 },
  { ep: "E05", views: 21000 },
  { ep: "E06", views: 31000 },
  { ep: "E07", views: 28500 },
];

export default function Dashboard() {
  const [series, setSeries] = useState([]);
  const [episodes, setEpisodes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [s, e] = await Promise.all([
          db.entities.Series.list("-created_date", 50),
          db.entities.Episode.list("-created_date", 50),
        ]);
        setSeries(s);
        setEpisodes(e);
      } catch {
        /* bubble */
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const pending = episodes.filter((e) => e.status === "in_review");
  const totalViews = episodes.reduce((sum, e) => sum + (e.views || 0), 0);
  const avgEng = episodes.length
    ? (episodes.reduce((s, e) => s + (e.engagement_rate || 0), 0) / episodes.length).toFixed(1)
    : "0";

  const stats = [
    { label: "Active series", value: series.length },
    { label: "Episodes published", value: episodes.filter((e) => e.status === "published").length },
    { label: "Total views", value: totalViews.toLocaleString() },
    { label: "Avg. engagement", value: `${avgEng}%` },
  ];

  return (
    <AppChrome
      breadcrumb={[{ label: "Studio" }, { label: "Dashboard" }]}
      actions={
        <Link to="/dashboard">
          <Button className="px-5 py-2.5 text-[14px]">New series</Button>
        </Link>
      }
    >
      <div className="mx-auto max-w-[1280px] px-8 py-10">
        {/* Stats */}
        <div className="grid gap-px overflow-hidden rounded-lg border border-mist sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="bg-paper p-6">
              <p className="text-[11px] text-steel">{s.label}</p>
              <p className="font-display mt-2 text-[26px] font-medium text-ink">{s.value}</p>
            </div>
          ))}
        </div>

        {/* Analytics + pending */}
        <div className="mt-8 grid gap-6 lg:grid-cols-3">
          <div className="rounded-lg border border-fog p-6 lg:col-span-2">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <p className="text-[11px] text-steel">Views per episode</p>
                <h3 className="text-[16px] font-medium text-ink">Audience growth</h3>
              </div>
              <TrendingUp className="h-4 w-4 text-steel" />
            </div>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="views" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#1a73e8" stopOpacity={0.15} />
                    <stop offset="100%" stopColor="#1a73e8" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis
                  dataKey="ep"
                  tick={{ fontSize: 11, fill: "#576579" }}
                  axisLine={{ stroke: "#e7eaee" }}
                  tickLine={false}
                />
                <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid #dbdfe5", fontSize: 13 }} />
                <Area type="monotone" dataKey="views" stroke="#1a73e8" strokeWidth={2} fill="url(#views)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="rounded-lg border border-fog p-6">
            <h3 className="mb-4 text-[16px] font-medium text-ink">Pending approvals</h3>
            {pending.length === 0 ? (
              <p className="text-[13px] text-steel">No episodes awaiting review.</p>
            ) : (
              <div className="space-y-3">
                {pending.map((e) => (
                  <Link
                    key={e.id}
                    to={`/editor/${e.series_id}`}
                    className="block rounded-lg border border-fog p-3 transition-colors hover:border-ash"
                  >
                    <p className="text-[14px] font-medium text-ink">{e.title}</p>
                    <p className="mt-0.5 text-[11px] text-steel">Episode {e.episode_number} · In review</p>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Series grid */}
        <div className="mt-12">
          <h2 className="font-display mb-6 text-[20px] font-medium text-ink">Your series</h2>
          {loading ? (
            <p className="text-[14px] text-steel">Loading…</p>
          ) : series.length === 0 ? (
            <p className="text-[14px] text-steel">No series yet. Create your first one.</p>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {series.map((s) => (
                <Link
                  key={s.id}
                  to={`/editor/${s.id}`}
                  className="group rounded-lg border border-fog p-4 transition-colors hover:border-ash"
                >
                  <div className="overflow-hidden rounded-2xl">
                    {s.cover_image ? (
                      <Image src={s.cover_image} alt={s.title} className="aspect-video w-full object-cover" fittingType="fill" />
                    ) : (
                      <div className="aspect-video w-full rounded-2xl bg-muted" />
                    )}
                  </div>
                  <div className="mt-4 flex items-center justify-between">
                    <p className="text-[11px] capitalize text-steel">{s.status?.replace("_", " ")}</p>
                    <p className="text-[11px] capitalize text-steel">{s.platform?.replace("_", " ")}</p>
                  </div>
                  <h3 className="mt-1 text-[16px] text-ink">{s.title}</h3>
                  {s.description && (
                    <p className="mt-1 line-clamp-2 text-[13px] text-steel" style={{ lineHeight: 1.5 }}>{s.description}</p>
                  )}
                  <div className="mt-4 inline-flex items-center gap-1 text-[13px] text-ink group-hover:text-signal">
                    Open editor <ArrowRight className="h-3.5 w-3.5" />
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </AppChrome>
  );
}