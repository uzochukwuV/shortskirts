const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from "react";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/components/ui/use-toast";
import AppChrome from "@/components/dysentry/AppChrome";
import Button from "@/components/dysentry/Button";

import { Check, Plug } from "lucide-react";

const platforms = [
  { id: "tiktok", label: "TikTok", note: "Connect to auto-publish episodes and shorts to your account." },
  { id: "youtube_shorts", label: "YouTube Shorts", note: "Connect to push shorts to your channel." },
];

const notifPrefs = [
  { key: "review_requests", label: "Review requests", desc: "When a scene is sent for your review." },
  { key: "publishing_complete", label: "Publishing complete", desc: "When a scheduled publish finishes." },
  { key: "job_failures", label: "Job failures", desc: "When a scheduled generation or publish fails." },
  { key: "weekly_summary", label: "Weekly summary", desc: "A weekly digest of your series performance." },
];

const defaults = {
  review_requests: true,
  publishing_complete: true,
  job_failures: true,
  weekly_summary: false,
};

export default function Settings() {
  const { toast } = useToast();
  const [prefs, setPrefs] = useState(defaults);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const me = await db.auth.me();
        setPrefs({ ...defaults, ...(me.notification_preferences || {}) });
      } catch {
        /* bubble */
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const persist = async (next) => {
    setSaving(true);
    try {
      await db.auth.updateMe({ notification_preferences: next });
    } catch {
      toast({ title: "Could not save preference", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const toggle = (key) => {
    setPrefs((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      persist(next);
      return next;
    });
  };

  const handleConnect = (p) => {
    toast({
      title: `Connect ${p.label}`,
      description: "Complete the connector setup shown in chat to enable this connection.",
    });
  };

  return (
    <AppChrome breadcrumb={[{ label: "Studio", path: "/dashboard" }, { label: "Settings" }]}>
      <div className="mx-auto max-w-3xl px-8 py-10">
        <h1 className="font-display mb-1 text-[26px] font-medium text-ink">Settings</h1>
        <p className="mb-10 text-[14px] text-steel">Manage platform connections and notification preferences.</p>

        {/* Connections */}
        <section>
          <h2 className="mb-4 text-[16px] font-medium text-ink">Connections</h2>
          <div className="space-y-3">
            {platforms.map((p) => (
              <div
                key={p.id}
                className="flex flex-col gap-3 rounded-lg border border-fog p-5 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <p className="text-[15px] font-medium text-ink">{p.label}</p>
                  <p className="mt-0.5 text-[13px] text-steel" style={{ lineHeight: 1.45 }}>
                    {p.note}
                  </p>
                </div>
                <Button
                  variant="outline"
                  className="shrink-0 px-4 py-2 text-[13px]"
                  onClick={() => handleConnect(p)}
                >
                  <Plug className="h-4 w-4" /> Connect
                </Button>
              </div>
            ))}
          </div>
        </section>

        {/* Notifications */}
        <section className="mt-12">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-[16px] font-medium text-ink">Email notifications</h2>
            {saving && <span className="text-[12px] text-steel">Saving…</span>}
          </div>
          <div className="divide-y divide-mist rounded-lg border border-fog">
            {notifPrefs.map((n) => (
              <div key={n.key} className="flex items-center justify-between p-5">
                <div>
                  <p className="text-[15px] text-ink">{n.label}</p>
                  <p className="mt-0.5 text-[13px] text-steel" style={{ lineHeight: 1.45 }}>
                    {n.desc}
                  </p>
                </div>
                <Switch checked={prefs[n.key]} onCheckedChange={() => toggle(n.key)} disabled={loading} />
              </div>
            ))}
          </div>
        </section>
      </div>
    </AppChrome>
  );
}