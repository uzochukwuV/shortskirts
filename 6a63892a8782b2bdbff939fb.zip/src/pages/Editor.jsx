const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState, useCallback } from "react";
import { useParams, Link } from "react-router-dom";

import { useToast } from "@/components/ui/use-toast";
import { Palette } from "lucide-react";
import Button from "@/components/dysentry/Button";
import Breadcrumb from "@/components/dysentry/Breadcrumb";
import SceneList from "@/components/dysentry/editor/SceneList";
import SceneStage from "@/components/dysentry/editor/SceneStage";
import AiChatPanel from "@/components/dysentry/editor/AiChatPanel";
import ExportMenu from "@/components/dysentry/editor/ExportMenu";
import CharacterDialog from "@/components/dysentry/editor/CharacterDialog";
import StyleMemoryDialog from "@/components/dysentry/editor/StyleMemoryDialog";

export default function Editor() {
  const { seriesId } = useParams();
  const { toast } = useToast();
  const [series, setSeries] = useState(null);
  const [episodes, setEpisodes] = useState([]);
  const [selectedEp, setSelectedEp] = useState(null);
  const [scenes, setScenes] = useState([]);
  const [selectedScene, setSelectedScene] = useState(null);
  const [characters, setCharacters] = useState([]);
  const [regenerating, setRegenerating] = useState(false);
  const [adding, setAdding] = useState(false);
  const [loading, setLoading] = useState(true);
  const [activeChar, setActiveChar] = useState(null);
  const [charOpen, setCharOpen] = useState(false);
  const [styleOpen, setStyleOpen] = useState(false);

  const loadAll = useCallback(async () => {
    const [s, eps, chars] = await Promise.all([
      db.entities.Series.get(seriesId),
      db.entities.Episode.filter({ series_id: seriesId }, "episode_number", 50),
      db.entities.Character.filter({ series_id: seriesId }, "-created_date", 50),
    ]);
    setSeries(s);
    setEpisodes(eps);
    setCharacters(chars);
    const ep = eps[0] || null;
    setSelectedEp(ep);
    if (ep) {
      const sc = await db.entities.Scene.filter({ episode_id: ep.id }, "order", 50);
      setScenes(sc);
      setSelectedScene(sc[0] || null);
    } else {
      setScenes([]);
      setSelectedScene(null);
    }
  }, [seriesId]);

  useEffect(() => {
    (async () => {
      try {
        await loadAll();
      } catch {
        /* bubble */
      } finally {
        setLoading(false);
      }
    })();
  }, [loadAll]);

  const selectEpisode = async (ep) => {
    setSelectedEp(ep);
    const sc = await db.entities.Scene.filter({ episode_id: ep.id }, "order", 50);
    setScenes(sc);
    setSelectedScene(sc[0] || null);
  };

  const patchScene = (patch) => {
    setScenes((prev) => prev.map((s) => (s.id === selectedScene.id ? { ...s, ...patch } : s)));
    setSelectedScene((prev) => ({ ...prev, ...patch }));
  };

  const saveScene = async (patch) => {
    try {
      await db.entities.Scene.update(selectedScene.id, patch);
    } catch {
      toast({ title: "Could not save scene", variant: "destructive" });
    }
  };

  const handleSave = () => {
    if (!selectedScene) return;
    saveScene({
      title: selectedScene.title,
      script: selectedScene.script,
      narration: selectedScene.narration,
      checkpoint_notes: selectedScene.checkpoint_notes,
      type: selectedScene.type,
    });
    toast({ title: "Scene saved" });
  };

  const handleCheckpoint = async (status) => {
    patchScene({ status });
    try {
      await db.entities.Scene.update(selectedScene.id, { status });
      toast({ title: status === "approved" ? "Scene approved" : "Sent for review" });
    } catch {
      toast({ title: "Update failed", variant: "destructive" });
    }
  };

  const handleRegenerate = async () => {
    if (!selectedScene) return;
    setRegenerating(true);
    patchScene({ status: "regenerating" });
    try {
      const charContext = characters
        .map((c) => `${c.name} (${c.role || "character"}): ${c.appearance || c.description || ""}`)
        .join("\n");
      const res = await db.integrations.Core.InvokeLLM({
        prompt: `You are a screenwriter for a serialized short-form story series titled "${series?.title}".

Series style memory: ${series?.style_memory || "(none)"}

Characters:
${charContext || "(none)"}

Current scene title: ${selectedScene.title || "Untitled"}
Current script: ${selectedScene.script || "(empty)"}

Rewrite and improve this scene script. Make it vivid, concise, and consistent with the characters and style. Return only the new script text, no preamble.`,
      });
      const newScript = typeof res === "string" ? res : res?.output || res?.text || JSON.stringify(res);
      patchScene({ script: newScript, status: "draft" });
      await db.entities.Scene.update(selectedScene.id, { script: newScript, status: "draft" });
      toast({ title: "Scene regenerated" });
    } catch {
      patchScene({ status: "draft" });
      toast({ title: "Regeneration failed", variant: "destructive" });
    } finally {
      setRegenerating(false);
    }
  };

  const handleAddScene = async () => {
    if (!selectedEp) return;
    setAdding(true);
    try {
      const order = (scenes.length ? Math.max(...scenes.map((s) => s.order || 0)) : 0) + 1;
      const created = await db.entities.Scene.create({
        episode_id: selectedEp.id,
        series_id: seriesId,
        order,
        title: `Scene ${order}`,
        type: "video",
        script: "",
        narration: "",
        status: "draft",
      });
      setScenes((prev) => [...prev, created]);
      setSelectedScene(created);
    } catch {
      toast({ title: "Could not add scene", variant: "destructive" });
    } finally {
      setAdding(false);
    }
  };

  const handleApplyScript = async (text) => {
    if (!selectedScene) return;
    patchScene({ script: text, status: "draft" });
    try {
      await db.entities.Scene.update(selectedScene.id, { script: text, status: "draft" });
      toast({ title: "Applied to scene" });
    } catch {
      toast({ title: "Could not save", variant: "destructive" });
    }
  };

  const handleAddSceneFromChat = async (text) => {
    if (!selectedEp) return;
    try {
      const order = (scenes.length ? Math.max(...scenes.map((s) => s.order || 0)) : 0) + 1;
      const created = await db.entities.Scene.create({
        episode_id: selectedEp.id,
        series_id: seriesId,
        order,
        title: `Scene ${order}`,
        type: "video",
        script: text,
        narration: "",
        status: "draft",
      });
      setScenes((prev) => [...prev, created]);
      setSelectedScene(created);
      toast({ title: "New scene added" });
    } catch {
      toast({ title: "Could not add scene", variant: "destructive" });
    }
  };

  const handleStyleSave = (val) => {
    setSeries((prev) => ({ ...prev, style_memory: val }));
    db.entities.Series.update(seriesId, { style_memory: val }).catch(() => {});
    toast({ title: "Style memory saved" });
  };

  const handleExport = (platforms) => {
    toast({ title: `Export prepared for ${platforms.join(", ")}` });
  };

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-mist border-t-ink" />
      </div>
    );
  }
  if (!series) {
    return <div className="flex h-screen items-center justify-center text-[14px] text-steel">Series not found.</div>;
  }

  return (
    <div className="flex h-screen flex-col bg-paper">
      {/* Top bar */}
      <header className="flex flex-wrap items-center gap-x-4 gap-y-2 border-b border-mist px-6 py-3">
        <Link to="/" className="font-display text-[18px] font-medium tracking-tight-bold text-ink">
          Dysentry
        </Link>
        <span className="text-ash">/</span>
        <Breadcrumb items={[{ label: "Studio", path: "/dashboard" }, { label: series.title }]} />
        <div className="ml-auto flex items-center gap-2">
          <Button variant="outline" className="px-4 py-2 text-[13px]" onClick={() => setStyleOpen(true)}>
            <Palette className="h-4 w-4" /> Style
          </Button>
          <Button variant="outline" className="px-4 py-2 text-[13px]" onClick={handleSave}>
            Save
          </Button>
          <ExportMenu onExport={handleExport} />
        </div>
      </header>

      {/* Episode + cast bar */}
      <div className="flex flex-wrap items-center gap-x-6 gap-y-2 border-b border-mist px-6 py-3">
        <div className="flex items-center gap-3">
          <span className="text-[11px] text-steel">Episode</span>
          <div className="flex flex-wrap items-center gap-1">
            {episodes.map((ep) => (
              <button
                key={ep.id}
                onClick={() => selectEpisode(ep)}
                className={`px-3 py-1.5 text-[14px] transition-colors ${selectedEp?.id === ep.id ? "border-b-2 border-ink font-medium text-ink" : "text-steel hover:text-ink"}`}
              >
                {String(ep.episode_number).padStart(2, "0")}
              </button>
            ))}
            {episodes.length === 0 && <span className="text-[13px] text-steel">No episodes</span>}
          </div>
        </div>
        {characters.length > 0 && (
          <div className="ml-auto flex items-center gap-2">
            <span className="text-[11px] text-steel">Cast</span>
            <div className="flex flex-wrap items-center gap-1.5">
              {characters.map((c) => (
                <button
                  key={c.id}
                  onClick={() => {
                    setActiveChar(c);
                    setCharOpen(true);
                  }}
                  title={c.name}
                  className="flex items-center gap-1.5 rounded-full border border-fog py-1 pl-1 pr-3 transition-colors hover:border-ash"
                >
                  <div className="flex h-6 w-6 items-center justify-center rounded-full bg-ink text-[11px] font-medium text-white">
                    {c.name?.[0]}
                  </div>
                  <span className="text-[12px] text-ink">{c.name}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Three panes: scene list | stage | AI chat */}
      <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-[280px_1fr_340px]">
        <div className="min-h-0 border-r border-mist">
          <SceneList
            scenes={scenes}
            selectedId={selectedScene?.id}
            onSelect={(id) => setSelectedScene(scenes.find((s) => s.id === id))}
            onAdd={handleAddScene}
            adding={adding}
          />
        </div>
        <div className="min-h-0 overflow-hidden border-r border-mist">
          <SceneStage
            scene={selectedScene}
            onChange={patchScene}
            onRegenerate={handleRegenerate}
            onCheckpoint={handleCheckpoint}
            regenerating={regenerating}
          />
        </div>
        <div className="min-h-0">
          <AiChatPanel
            series={series}
            characters={characters}
            scene={selectedScene}
            onApplyScript={handleApplyScript}
            onAddScene={handleAddSceneFromChat}
          />
        </div>
      </div>

      <CharacterDialog character={activeChar} open={charOpen} onOpenChange={setCharOpen} />
      <StyleMemoryDialog
        open={styleOpen}
        onOpenChange={setStyleOpen}
        value={series?.style_memory}
        onSave={handleStyleSave}
      />
    </div>
  );
}