const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState, useCallback } from "react";
import { Plus, CalendarClock } from "lucide-react";

import { useToast } from "@/components/ui/use-toast";
import AppChrome from "@/components/dysentry/AppChrome";
import Button from "@/components/dysentry/Button";
import ScheduleForm from "@/components/dysentry/schedule/ScheduleForm";
import ScheduledJobCard from "@/components/dysentry/schedule/ScheduledJobCard";

export default function Schedule() {
  const { toast } = useToast();
  const [jobs, setJobs] = useState([]);
  const [series, setSeries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);

  const load = useCallback(async () => {
    try {
      const [s, j] = await Promise.all([
        db.entities.Series.list("-created_date", 50),
        db.entities.ScheduledJob.list("scheduled_time", 50),
      ]);
      setSeries(s);
      setJobs(j);
    } catch {
      /* bubble */
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const handleCancel = async (job) => {
    try {
      await db.entities.ScheduledJob.update(job.id, { status: "cancelled" });
      setJobs((prev) => prev.map((j) => (j.id === job.id ? { ...j, status: "cancelled" } : j)));
      toast({ title: "Job cancelled" });
    } catch {
      toast({ title: "Could not cancel", variant: "destructive" });
    }
  };

  const seriesTitle = (id) => series.find((s) => s.id === id)?.title;

  return (
    <AppChrome
      breadcrumb={[{ label: "Studio", path: "/dashboard" }, { label: "Schedule" }]}
      actions={
        <Button className="px-5 py-2.5 text-[14px]" onClick={() => setFormOpen(true)}>
          <Plus className="h-4 w-4" /> New job
        </Button>
      }
    >
      <div className="mx-auto max-w-3xl px-8 py-10">
        <h1 className="font-display mb-1 text-[26px] font-medium text-ink">Schedule</h1>
        <p className="mb-10 text-[14px] text-steel" style={{ lineHeight: 1.5 }}>
          Automate series and episode generation, or publish finished episodes to social platforms at a chosen time.
        </p>

        {loading ? (
          <p className="text-[14px] text-steel">Loading…</p>
        ) : jobs.length === 0 ? (
          <div className="rounded-lg border border-dashed border-fog py-16 text-center">
            <CalendarClock className="mx-auto h-8 w-8 text-ash" />
            <p className="mt-3 text-[14px] text-steel">No scheduled jobs yet.</p>
            <button
              onClick={() => setFormOpen(true)}
              className="mt-2 text-[14px] text-signal transition-colors hover:text-[#1557b8]"
            >
              Schedule your first job
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {jobs.map((job) => (
              <ScheduledJobCard
                key={job.id}
                job={job}
                seriesTitle={seriesTitle(job.series_id)}
                onCancel={handleCancel}
              />
            ))}
          </div>
        )}
      </div>

      <ScheduleForm open={formOpen} onOpenChange={setFormOpen} series={series} onCreated={load} />
    </AppChrome>
  );
}