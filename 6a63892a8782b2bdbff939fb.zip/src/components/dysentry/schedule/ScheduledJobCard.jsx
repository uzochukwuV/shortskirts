import React from "react";
import { Film, Sparkles, Send, CalendarClock, X } from "lucide-react";

const typeMeta = {
  generate_series: { label: "Generate series", icon: Sparkles },
  generate_episode: { label: "Generate episode", icon: Film },
  publish_episode: { label: "Publish episode", icon: Send },
};

const statusStyles = {
  pending: "text-steel border-fog",
  running: "text-signal border-signal/30",
  completed: "text-ink border-ink/20",
  failed: "text-destructive border-destructive/30",
  cancelled: "text-ash border-ash",
};

const statusLabel = {
  pending: "Pending",
  running: "Running",
  completed: "Completed",
  failed: "Failed",
  cancelled: "Cancelled",
};

const platformLabel = {
  tiktok: "TikTok",
  youtube_shorts: "YouTube Shorts",
  reels: "Reels",
  stories: "Stories",
};

export default function ScheduledJobCard({ job, seriesTitle, episodeTitle, onCancel }) {
  const meta = typeMeta[job.job_type] || typeMeta.generate_episode;
  const Icon = meta.icon;
  const dt = job.scheduled_time ? new Date(job.scheduled_time) : null;

  return (
    <div className="rounded-lg border border-fog p-5">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted">
            <Icon className="h-4 w-4 text-ink" />
          </div>
          <div>
            <p className="text-[15px] font-medium text-ink">{meta.label}</p>
            <p className="mt-0.5 text-[12px] text-steel">{seriesTitle || "—"}</p>
          </div>
        </div>
        <span className={`rounded-full border px-2.5 py-0.5 text-[11px] ${statusStyles[job.status]}`}>
          {statusLabel[job.status]}
        </span>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-1 text-[13px] text-steel">
        <span className="inline-flex items-center gap-1.5">
          <CalendarClock className="h-3.5 w-3.5" />
          {dt ? dt.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" }) : "—"}
        </span>
        {job.platform && job.job_type === "publish_episode" && (
          <span>→ {platformLabel[job.platform] || job.platform}</span>
        )}
        {episodeTitle && <span>Ep: {episodeTitle}</span>}
      </div>

      {job.notes && (
        <p className="mt-3 text-[13px] text-steel" style={{ lineHeight: 1.5 }}>{job.notes}</p>
      )}

      {job.status === "pending" && (
        <button
          onClick={() => onCancel(job)}
          className="mt-4 inline-flex items-center gap-1 text-[12px] text-steel transition-colors hover:text-destructive"
        >
          <X className="h-3.5 w-3.5" /> Cancel job
        </button>
      )}
    </div>
  );
}