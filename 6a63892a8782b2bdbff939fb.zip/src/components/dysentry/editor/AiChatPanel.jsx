const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useRef, useEffect } from "react";
import { Send, Sparkles, FileText, Plus } from "lucide-react";

export default function AiChatPanel({ series, characters, scene, onApplyScript, onAddScene }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, sending]);

  const buildContext = () => {
    const charContext = characters
      .map((c) => `- ${c.name} (${c.role || "character"}): ${c.appearance || c.description || ""}`)
      .join("\n");
    return `Series: ${series?.title || ""}
Style memory: ${series?.style_memory || "(none)"}
Characters:
${charContext || "(none)"}
Current scene: ${scene?.title || "Untitled"}
Current script: ${scene?.script || "(empty)"}`;
  };

  const send = async () => {
    if (!input.trim() || sending) return;
    const userMsg = { role: "user", text: input.trim() };
    const history = [...messages, userMsg];
    setMessages(history);
    setInput("");
    setSending(true);
    try {
      const res = await db.integrations.Core.InvokeLLM({
        prompt: `You are a collaborative screenwriting assistant for a serialized short-form story. Use the context below to help the user rewrite, expand, or generate scene content. When the user asks to rewrite or generate a script, return ONLY the new script text (no preamble, no markdown fences). Otherwise, respond conversationally and concisely.

=== CONTEXT ===
${buildContext()}

=== CONVERSATION ===
${history.map((m) => `${m.role === "user" ? "User" : "Assistant"}: ${m.text}`).join("\n")}

Assistant:`,
      });
      const text = typeof res === "string" ? res : res?.output || res?.text || JSON.stringify(res);
      setMessages([...history, { role: "assistant", text }]);
    } catch {
      setMessages([
        ...history,
        { role: "assistant", text: "Sorry, I couldn't generate a response. Please try again." },
      ]);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex flex-col lg:h-full">
      {/* Header */}
      <div className="flex items-center gap-2 border-b border-mist px-5 py-4">
        <Sparkles className="h-4 w-4 text-signal" />
        <h3 className="text-[14px] font-medium tracking-tight-bold text-ink">AI assistant</h3>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto px-5 py-5">
        {messages.length === 0 && (
          <div className="pt-8 text-center">
            <Sparkles className="mx-auto h-8 w-8 text-ash" />
            <p className="mt-3 text-[13px] text-steel" style={{ lineHeight: 1.5 }}>
              Ask me to rewrite the current scene, add a twist, or draft the next one.
            </p>
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-[14px] ${m.role === "user" ? "bg-ink text-white" : "bg-muted text-ink"}`}
              style={{ lineHeight: 1.5 }}
            >
              <p className="whitespace-pre-wrap">{m.text}</p>
              {m.role === "assistant" && (
                <div className="mt-3 flex gap-3 border-t border-fog/60 pt-2">
                  <button
                    onClick={() => onApplyScript(m.text)}
                    className="inline-flex items-center gap-1 text-[12px] text-signal transition-colors hover:text-[#1557b8]"
                  >
                    <FileText className="h-3.5 w-3.5" /> Apply to scene
                  </button>
                  <button
                    onClick={() => onAddScene(m.text)}
                    className="inline-flex items-center gap-1 text-[12px] text-steel transition-colors hover:text-ink"
                  >
                    <Plus className="h-3.5 w-3.5" /> New scene
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
        {sending && (
          <div className="flex justify-start">
            <div className="rounded-2xl bg-muted px-4 py-2.5 text-[14px] text-steel">Thinking…</div>
          </div>
        )}
      </div>

      {/* Input */}
      <div className="border-t border-mist p-3">
        <div className="flex items-end gap-2 rounded-lg border border-fog bg-white px-3 py-2 focus-within:border-ash">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send();
              }
            }}
            placeholder="Ask the assistant…"
            rows={1}
            className="flex-1 resize-none bg-transparent text-[14px] text-ink outline-none placeholder-steel"
            style={{ lineHeight: 1.5, maxHeight: 120 }}
          />
          <button
            onClick={send}
            disabled={sending || !input.trim()}
            className="shrink-0 rounded-md bg-signal p-2 text-white transition-colors hover:bg-[#1557b8] disabled:opacity-50"
          >
            <Send className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}